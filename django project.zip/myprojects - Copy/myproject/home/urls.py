from django.contrib import admin
from django.urls import path, include
from home import views
from home.views import CompanyViewSet
from rest_framework import routers

router = routers.DefaultRouter()
router.register(r'company', CompanyViewSet)

urlpatterns = [
    path("",views.index, name="home"),
    path("home/",views.index, name="home"),
    path("services/", views.services, name="services"),
    path("contact/", views.contact, name="contact"),
    path("about/", views.about, name="about"),
    path('Menu/', views.Menu, name='Menu'),
    path("signup", views.handleSignup, name="handleSignup"),
    path("login", views.handlelogin, name="handlelogin"),
    path("logout", views.handlelogout, name="handlelogout"),
    path('', include(router.urls)),
]

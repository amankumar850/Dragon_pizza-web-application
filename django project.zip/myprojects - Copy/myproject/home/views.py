from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from home.models import Contact
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
import requests
from rest_framework import viewsets
from home.models import Company
from home.serializers import CompanySerializer

# Create your views here.
def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def services(request):
    return render(request, 'services.html')

def Menu(request):
    return render(request, 'Menu.html')

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
        messages.success(request, "Your message has been sent!")
    return render(request, 'contact.html')


def handleSignup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        pass1 = request.POST.get('pass1')    
        pass2 = request.POST.get('pass2')
        myuser = User.objects.create_user(username,email,pass1)
        myuser.first_name = fname
        myuser.lname_name = lname
        pass1==pass2
        myuser.save()
        messages.success(request,"your account has been created successfully!")
        return redirect('home')
    
    else:
        return HttpResponse('404 - not found')
    
def handlelogin(request):
    if request.method == "POST":
        loginusername = request.POST.get('loginusername')
        loginpassword = request.POST.get('loginpassword')

        user = authenticate(username=loginusername,password=loginpassword )

        if user is not None:
            login(request, user)
            messages.success(request, "successfully login!")
            return redirect('home')

        else:
            messages.error(request, "invalid Credential, please try again")
            return redirect('home')
        
    return HttpResponse('404 - not found')


def handlelogout(request):
    logout(request)
    messages.success(request, "successfully logged out!")
    return redirect('home')


class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    